function sub()
{
    window.open("findkaoheServlet");
}

function login()
{
    window.open("login.jsp");
}
